﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics.Metrics;

namespace School_Manager
{
    public partial class Student_Editor : Form
    {
        //Reference to the start page
        private Start_Page startPage;
        string filePath = "students.txt";
        int counterF = 2;
        int counterS = 4;
        private BindingList<Student> students = Start_Page.startPage.students;
        public Student_Editor(Start_Page startPage_)
        {
            InitializeComponent();
            startPage = startPage_;

            for (int i = 1; i < 31; i++)
            {
                string selectedLine = File.ReadLines(filePath).Skip(counterF - 1).FirstOrDefault();
                string selectedLine1 = File.ReadLines(filePath).Skip(counterS - 1).FirstOrDefault();
                listBox1.Items.Add(selectedLine+" "+selectedLine1);
                counterF += 8;
                counterS += 8;
            }
        }

        //End the application if this form is closed
        private void Student_Editor_Form_Closing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        //Back button
        private void Button1_Click(object sender, EventArgs e)
        {
            FormFns.SwitchForms(this, startPage.adminHomePage);
        }

        private void Student_Editor_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {               
            string firstName = File.ReadLines(filePath).Skip(listBox1.SelectedIndex*8 + 1).FirstOrDefault();
            string middleName = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 2).FirstOrDefault();
            string lastName = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 3).FirstOrDefault();
            string gender = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 4).FirstOrDefault();
            string dob = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 5).FirstOrDefault();
            string mail = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 6).FirstOrDefault();
            string phone = File.ReadLines(filePath).Skip(listBox1.SelectedIndex * 8 + 7).FirstOrDefault();

            textBox1.Text = (firstName);
            textBox2.Text = (lastName);
            textBox3.Text = (middleName);
            textBox4.Text = (gender);
            textBox5.Text = (dob);
            textBox6.Text = (mail);
            textBox7.Text = (phone);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {   
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        //return to form
        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //save new student info

            //String of the old txt file
            string[] studentsT = File.ReadAllLines(filePath);

            //Text to write to the new file
            studentsT[listBox1.SelectedIndex * 8 + 1] = textBox1.Text;
            studentsT[listBox1.SelectedIndex * 8 + 2] = textBox2.Text;
            studentsT[listBox1.SelectedIndex * 8 + 3] = textBox3.Text;
            studentsT[listBox1.SelectedIndex * 8 + 4] = textBox4.Text;
            studentsT[listBox1.SelectedIndex * 8 + 5] = textBox5.Text;
            studentsT[listBox1.SelectedIndex * 8 + 6] = textBox6.Text;
            studentsT[listBox1.SelectedIndex * 8 + 7] = textBox7.Text;

            
            string newStudents = string.Join("\n", studentsT);



            try
            {
                // Open the file for writing (creates the file if it doesn't exist)
                using(StreamWriter writer = new StreamWriter("../../../students.txt"))
                // Write the content to the file
                writer.Write(newStudents);

                MessageBox.Show("it worked");

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        ///////////////////////////////
        ///To reference another form, use startPage.form, i.e. startPage.adminLogin or startPage.classEditor
    }
}
